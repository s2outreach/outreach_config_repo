package com.cts.outreach.email.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix="email")
public class ReportMailConfig {
	
	private String reportinsightsubject;
	private String reportinsightmailLine1;
	private String reportinsightmailLine2;
	private String reportinsightmailLine3;
	private String reportinsightmailLine4;
	private String reportinsightmailLine5;
	private String reportinsightmailLine6;
	private String reportinsightmailLine7;
	private String reportinsightmailLine8;
	private String reportinsightmailLine9;
	private String reportinsightmailLine10;
	private String reportinsightmailLine11;
	private String reportinsightmailLine12;
	private String reportinsightmailLine13;
	private String reportinsightmailLine14;
	private String reportinsightmailLine15;
	private String reportinsightmailLine16;
	private String reportinsightmailLine17;
	private String reportinsightmailLine18;
	private String reportinsightmailLine19;
	private String reportinsightmailLine20;
	private String reportinsightmailLine21;
	private String reportinsightmailLine22;
	public String getReportinsightsubject() {
		return reportinsightsubject;
	}
	public void setReportinsightsubject(String reportinsightsubject) {
		this.reportinsightsubject = reportinsightsubject;
	}
	public String getReportinsightmailLine1() {
		return reportinsightmailLine1;
	}
	public void setReportinsightmailLine1(String reportinsightmailLine1) {
		this.reportinsightmailLine1 = reportinsightmailLine1;
	}
	public String getReportinsightmailLine2() {
		return reportinsightmailLine2;
	}
	public void setReportinsightmailLine2(String reportinsightmailLine2) {
		this.reportinsightmailLine2 = reportinsightmailLine2;
	}
	public String getReportinsightmailLine3() {
		return reportinsightmailLine3;
	}
	public void setReportinsightmailLine3(String reportinsightmailLine3) {
		this.reportinsightmailLine3 = reportinsightmailLine3;
	}
	public String getReportinsightmailLine4() {
		return reportinsightmailLine4;
	}
	public void setReportinsightmailLine4(String reportinsightmailLine4) {
		this.reportinsightmailLine4 = reportinsightmailLine4;
	}
	public String getReportinsightmailLine5() {
		return reportinsightmailLine5;
	}
	public void setReportinsightmailLine5(String reportinsightmailLine5) {
		this.reportinsightmailLine5 = reportinsightmailLine5;
	}
	public String getReportinsightmailLine6() {
		return reportinsightmailLine6;
	}
	public void setReportinsightmailLine6(String reportinsightmailLine6) {
		this.reportinsightmailLine6 = reportinsightmailLine6;
	}
	public String getReportinsightmailLine7() {
		return reportinsightmailLine7;
	}
	public void setReportinsightmailLine7(String reportinsightmailLine7) {
		this.reportinsightmailLine7 = reportinsightmailLine7;
	}
	public String getReportinsightmailLine8() {
		return reportinsightmailLine8;
	}
	public void setReportinsightmailLine8(String reportinsightmailLine8) {
		this.reportinsightmailLine8 = reportinsightmailLine8;
	}
	public String getReportinsightmailLine9() {
		return reportinsightmailLine9;
	}
	public void setReportinsightmailLine9(String reportinsightmailLine9) {
		this.reportinsightmailLine9 = reportinsightmailLine9;
	}
	public String getReportinsightmailLine10() {
		return reportinsightmailLine10;
	}
	public void setReportinsightmailLine10(String reportinsightmailLine10) {
		this.reportinsightmailLine10 = reportinsightmailLine10;
	}
	public String getReportinsightmailLine11() {
		return reportinsightmailLine11;
	}
	public void setReportinsightmailLine11(String reportinsightmailLine11) {
		this.reportinsightmailLine11 = reportinsightmailLine11;
	}
	public String getReportinsightmailLine12() {
		return reportinsightmailLine12;
	}
	public void setReportinsightmailLine12(String reportinsightmailLine12) {
		this.reportinsightmailLine12 = reportinsightmailLine12;
	}
	public String getReportinsightmailLine13() {
		return reportinsightmailLine13;
	}
	public void setReportinsightmailLine13(String reportinsightmailLine13) {
		this.reportinsightmailLine13 = reportinsightmailLine13;
	}
	public String getReportinsightmailLine14() {
		return reportinsightmailLine14;
	}
	public void setReportinsightmailLine14(String reportinsightmailLine14) {
		this.reportinsightmailLine14 = reportinsightmailLine14;
	}
	public String getReportinsightmailLine15() {
		return reportinsightmailLine15;
	}
	public void setReportinsightmailLine15(String reportinsightmailLine15) {
		this.reportinsightmailLine15 = reportinsightmailLine15;
	}
	public String getReportinsightmailLine16() {
		return reportinsightmailLine16;
	}
	public void setReportinsightmailLine16(String reportinsightmailLine16) {
		this.reportinsightmailLine16 = reportinsightmailLine16;
	}
	public String getReportinsightmailLine17() {
		return reportinsightmailLine17;
	}
	public void setReportinsightmailLine17(String reportinsightmailLine17) {
		this.reportinsightmailLine17 = reportinsightmailLine17;
	}
	public String getReportinsightmailLine18() {
		return reportinsightmailLine18;
	}
	public void setReportinsightmailLine18(String reportinsightmailLine18) {
		this.reportinsightmailLine18 = reportinsightmailLine18;
	}
	public String getReportinsightmailLine19() {
		return reportinsightmailLine19;
	}
	public void setReportinsightmailLine19(String reportinsightmailLine19) {
		this.reportinsightmailLine19 = reportinsightmailLine19;
	}
	public String getReportinsightmailLine20() {
		return reportinsightmailLine20;
	}
	public void setReportinsightmailLine20(String reportinsightmailLine20) {
		this.reportinsightmailLine20 = reportinsightmailLine20;
	}
	public String getReportinsightmailLine21() {
		return reportinsightmailLine21;
	}
	public void setReportinsightmailLine21(String reportinsightmailLine21) {
		this.reportinsightmailLine21 = reportinsightmailLine21;
	}
	public String getReportinsightmailLine22() {
		return reportinsightmailLine22;
	}
	public void setReportinsightmailLine22(String reportinsightmailLine22) {
		this.reportinsightmailLine22 = reportinsightmailLine22;
	}

}
